import { AppState, UnitInput } from '../types';

export const calculateUnitArea = (u: UnitInput) => {
  const totalWidth = (u.width1 || 0) + (u.width2 || 0) + (u.width3 || 0) + (u.width4 || 0);
  return (totalWidth / 100) * (u.height / 100);
};

export const calculateUnitTotal = (u: UnitInput) => {
  return calculateUnitArea(u) * (u.pricePerMeter || 0);
};

export const calculateTotals = (state: AppState) => {
  const baseUnits = state.units.filter(u => u.category === 'base');
  const wallUnits = state.units.filter(u => u.category === 'wall');
  const tallUnits = state.units.filter(u => u.category === 'tall');
  const sideUnits = state.units.filter(u => u.category === 'side');
  const marbleUnits = state.units.filter(u => u.category === 'marble');

  const totalBase = baseUnits.reduce((acc, u) => acc + calculateUnitTotal(u), 0);
  const totalWall = wallUnits.reduce((acc, u) => acc + calculateUnitTotal(u), 0);
  const totalTall = tallUnits.reduce((acc, u) => acc + calculateUnitTotal(u), 0);
  const totalSides = sideUnits.reduce((acc, u) => acc + calculateUnitTotal(u), 0);
  
  const totalWood = totalBase + totalWall + totalTall + totalSides;
  
  const totalAccessories = state.accessories.reduce((acc, a) => acc + (a.quantity * a.pricePerUnit), 0);
  const totalMarble = marbleUnits.reduce((acc, u) => acc + calculateUnitTotal(u), 0);
  
  const contractTotal = totalWood + totalAccessories + totalMarble;

  const detailedCostsTotal = state.detailedCosts.reduce((acc, item) => acc + (item.quantity * item.pricePerUnit), 0);

  // Instead of using just additionalMaterials, let's use the actual wood/marble/accessories + detailedCosts as rawMaterials
  // Or fallback to contractTotal if there's no detailed costs. 
  // Let's make it more logical: rawMaterials = sum of everything.
  const rawMaterials = Math.max(contractTotal, detailedCostsTotal) + (state.labor.additionalMaterials || 0);
  
  // Labor calculation
  let laborTotal = (state.labor.carpentry || 0) + (state.labor.installation || 0) + 
                   (state.labor.transport || 0) + (state.labor.others || 0);
                   
  if (state.margins.laborPercent && state.margins.laborPercent > 0) {
    laborTotal = rawMaterials * (state.margins.laborPercent / 100);
  }

  const basicCost = rawMaterials + laborTotal;
  const profitValue = basicCost * (state.margins.profitPercent / 100);
  const contingencyValue = basicCost * (state.margins.contingencyPercent / 100);
  const finalPrice = basicCost + profitValue + contingencyValue;
  
  const netProfit = finalPrice - basicCost;
  const netProfitPercent = basicCost > 0 ? (netProfit / finalPrice) * 100 : 0;

  return {
    totalWood,
    totalAccessories,
    totalMarble,
    contractTotal,
    detailedCostsTotal,
    rawMaterials,
    laborTotal,
    basicCost,
    profitValue,
    contingencyValue,
    finalPrice,
    netProfit,
    netProfitPercent
  };
};
