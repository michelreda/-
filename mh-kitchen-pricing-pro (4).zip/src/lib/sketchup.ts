declare global {
  interface Window {
    sketchup?: {
      ready: () => void;
      read_dimensions: () => void;
      [key: string]: any;
    };
    skpCallback_onDimensionsRead?: (data: { width: number; depth: number; height: number; name?: string }) => void;
    skpCallback_onSelectionChange?: (data: { width: number; depth: number; height: number; name?: string } | null) => void;
    skpCallback_onError?: (msg: string) => void;
  }
}

export const initSketchup = () => {
  if (window.sketchup && window.sketchup.ready) {
    window.sketchup.ready();
  }
};

export const readDimensionsFromSketchup = (): Promise<{ width: number; depth: number; height: number; name?: string }> => {
  return new Promise((resolve, reject) => {
    if (window.sketchup && window.sketchup.read_dimensions) {
      window.skpCallback_onDimensionsRead = (data) => {
        resolve(data);
      };
      window.skpCallback_onError = (msg) => {
        reject(new Error(msg));
      };
      window.sketchup.read_dimensions();
    } else {
      reject(new Error("SketchUp API not available. This feature only works when running inside SketchUp."));
    }
  });
};

export const subscribeToSketchupSelection = (callback: (data: { width: number; depth: number; height: number; name?: string } | null) => void) => {
  window.skpCallback_onSelectionChange = callback;
};
