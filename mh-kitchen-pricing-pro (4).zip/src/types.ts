export interface ProjectInfo {
  customerName: string;
  projectNumber: string;
  engineer: string;
  date: string;
  address: string;
  phone: string;
  notes: string;
}

export type UnitCategory = 'base' | 'wall' | 'tall' | 'side' | 'marble';

export interface UnitInput {
  id: string;
  category: UnitCategory;
  width1: number;
  width2: number;
  width3: number;
  width4: number;
  height: number;
  pricePerMeter: number;
}

export interface AccessoryInput {
  id: string;
  name: string;
  notes: string;
  quantity: number;
  pricePerUnit: number;
}

export interface DetailedCostItem {
  id: string;
  name: string;
  description: string;
  quantity: number;
  unit: string;
  pricePerUnit: number;
}

export interface LaborCost {
  carpentry: number;
  installation: number;
  transport: number;
  others: number;
  additionalMaterials: number;
}

export interface Margins {
  profitPercent: number;
  contingencyPercent: number;
  laborPercent?: number;
}

export interface TimelineTask {
  id: string;
  phase: string;
  startDate: string;
  endDate: string;
  duration: number;
  status: 'not_started' | 'in_progress' | 'completed';
  notes: string;
}

export interface AppState {
  language: 'en' | 'ar';
  theme: 'light' | 'dark';
  currentTab: string;
  projectInfo: ProjectInfo;
  units: UnitInput[];
  accessories: AccessoryInput[];
  detailedCosts: DetailedCostItem[];
  labor: LaborCost;
  margins: Margins;
  timeline: TimelineTask[];
}

export interface SavedProject {
  id: string;
  timestamp: number;
  state: Omit<AppState, 'language' | 'theme' | 'currentTab'>;
}

export type Database = typeof import('./data/database.json');
