import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppState, ProjectInfo, UnitInput, AccessoryInput, DetailedCostItem, LaborCost, Margins, TimelineTask, SavedProject } from './types';
import databaseData from './data/database.json';
import { initSketchup, subscribeToSketchupSelection } from './lib/sketchup';

const defaultState: AppState = {
  language: 'ar',

  theme: 'light',
  currentTab: 'dashboard',
  projectInfo: {
    customerName: '',
    projectNumber: `PRJ-${Math.floor(Math.random() * 10000)}`,
    engineer: '',
    date: new Date().toISOString().split('T')[0],
    address: '',
    phone: '',
    notes: ''
  },
  units: [],
  accessories: [
    { id: '1', name: 'سلايدر', notes: '', quantity: 0, pricePerUnit: 0 },
    { id: '2', name: 'مفصلات', notes: '', quantity: 0, pricePerUnit: 0 },
    { id: '3', name: 'مقابض', notes: '', quantity: 0, pricePerUnit: 0 },
    { id: '4', name: 'قاعدة بوتاجاز', notes: '', quantity: 0, pricePerUnit: 0 },
    { id: '5', name: 'ماسورة', notes: '', quantity: 0, pricePerUnit: 0 },
    { id: '6', name: 'مطبقية', notes: '', quantity: 0, pricePerUnit: 0 },
  ],
  detailedCosts: [
    { id: '1', name: 'ألواح جسم المطبخ', description: 'MDF / خشب طبيعي', quantity: 0, unit: 'متر مربع', pricePerUnit: 2600 },
    { id: '2', name: 'ألواح ضلف المطبخ', description: 'MDF / خشب طبيعي', quantity: 0, unit: 'متر مربع', pricePerUnit: 3200 },
    { id: '3', name: 'ألواح ظهور', description: 'MDF', quantity: 0, unit: 'متر مربع', pricePerUnit: 500 },
    { id: '4', name: 'شريط حرف', description: 'شريط حواف ABS', quantity: 0, unit: 'متر', pricePerUnit: 8 },
    { id: '5', name: 'مفصلات', description: 'مفصلات للأبواب', quantity: 0, unit: 'قطعة', pricePerUnit: 45 },
    { id: '6', name: 'مجرى درج', description: 'مجرى درج معدني', quantity: 0, unit: 'قطعة', pricePerUnit: 180 },
    { id: '7', name: 'زاوية تجميع', description: 'زاوية تجميع معدنية', quantity: 0, unit: 'قطعة', pricePerUnit: 12 },
    { id: '8', name: 'قطاع معدن للضلف', description: 'قطاع معدن للأبواب', quantity: 0, unit: 'قطعة', pricePerUnit: 250 },
    { id: '9', name: 'مقابض قطاع معدن', description: 'مقابض معدنية للأبواب', quantity: 0, unit: 'قطعة', pricePerUnit: 120 },
    { id: '10', name: 'مقابض عادي', description: 'مقابض بلاستيكية', quantity: 0, unit: 'قطعة', pricePerUnit: 25 },
    { id: '11', name: 'رجول', description: 'رجول للأثاث', quantity: 0, unit: 'قطعة', pricePerUnit: 8 },
    { id: '12', name: 'دراع قلاب', description: 'دراع قلاب معدني', quantity: 0, unit: 'قطعة', pricePerUnit: 220 },
    { id: '13', name: 'ضلف زجاج', description: 'ضلف زجاجية', quantity: 0, unit: 'قطعة', pricePerUnit: 450 },
    { id: '14', name: 'تكاليف مصنعيات', description: 'تكاليف العمالة والتركيب', quantity: 0, unit: '-', pricePerUnit: 0 },
  ],
  labor: {
    carpentry: 0,
    installation: 0,
    transport: 0,
    others: 0,
    additionalMaterials: 0,
  },
  margins: {
    profitPercent: 20,
    contingencyPercent: 12,
  },
  timeline: [
    { id: '1', phase: 'رفع المقاسات', startDate: '', endDate: '', duration: 0, status: 'not_started', notes: '' },
    { id: '2', phase: 'التصميم (SketchUp)', startDate: '', endDate: '', duration: 0, status: 'not_started', notes: '' },
    { id: '3', phase: 'موافقة العميل على التصميم', startDate: '', endDate: '', duration: 0, status: 'not_started', notes: '' },
    { id: '4', phase: 'التصنيع', startDate: '', endDate: '', duration: 0, status: 'not_started', notes: '' },
    { id: '5', phase: 'التركيب', startDate: '', endDate: '', duration: 0, status: 'not_started', notes: '' },
    { id: '6', phase: 'التسليم النهائي', startDate: '', endDate: '', duration: 0, status: 'not_started', notes: '' },
  ]
};

interface AppContextType {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
  sketchupSelection: { width: number; depth: number; height: number; name?: string } | null;
  updateProjectInfo: (updates: Partial<ProjectInfo>) => void;
  updateLabor: (updates: Partial<LaborCost>) => void;
  updateMargins: (updates: Partial<Margins>) => void;
  setLanguage: (lang: 'en' | 'ar') => void;
  setTheme: (theme: 'light' | 'dark') => void;
  setTab: (tab: string) => void;
  savedProjects: SavedProject[];
  saveProject: () => void;
  loadProject: (id: string) => void;
  deleteProject: (id: string) => void;
  t: (key: string) => string;
  db: typeof databaseData;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>(defaultState);
  const [savedProjects, setSavedProjects] = useState<SavedProject[]>([]);
  const [sketchupSelection, setSketchupSelection] = useState<{ width: number; depth: number; height: number; name?: string } | null>(null);

  useEffect(() => {
    initSketchup();
    subscribeToSketchupSelection((data) => {
      setSketchupSelection(data);
    });

    const saved = localStorage.getItem('mh_kitchen_projects');
    if (saved) {
      try {
        setSavedProjects(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load projects');
      }
    }

    const autoSaved = localStorage.getItem('mh_kitchen_auto_save');
    if (autoSaved) {
      try {
        const parsed = JSON.parse(autoSaved);
        setState({ ...parsed, currentTab: 'dashboard' });
      } catch (e) {
        console.error('Failed to load auto-save');
      }
    }
  }, []);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      localStorage.setItem('mh_kitchen_auto_save', JSON.stringify(state));
    }, 1000);
    return () => clearTimeout(timeoutId);
  }, [state]);

  useEffect(() => {
    if (state.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.theme]);

  useEffect(() => {
    document.documentElement.dir = state.language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = state.language;
  }, [state.language]);

  const updateProjectInfo = (updates: Partial<ProjectInfo>) => 
    setState(s => ({ ...s, projectInfo: { ...s.projectInfo, ...updates } }));

  const updateLabor = (updates: Partial<LaborCost>) => 
    setState(s => ({ ...s, labor: { ...s.labor, ...updates } }));

  const updateMargins = (updates: Partial<Margins>) => 
    setState(s => ({ ...s, margins: { ...s.margins, ...updates } }));

  const setLanguage = (lang: 'en' | 'ar') => setState(s => ({ ...s, language: lang }));
  const setTheme = (theme: 'light' | 'dark') => setState(s => ({ ...s, theme }));
  const setTab = (tab: string) => setState(s => ({ ...s, currentTab: tab }));

  const saveProject = () => {
    const newProject: SavedProject = {
      id: state.projectInfo.projectNumber,
      timestamp: Date.now(),
      state: {
        projectInfo: state.projectInfo,
        units: state.units,
        accessories: state.accessories,
        detailedCosts: state.detailedCosts,
        labor: state.labor,
        margins: state.margins,
        timeline: state.timeline
      }
    };
    
    setSavedProjects(prev => {
      const filtered = prev.filter(p => p.id !== newProject.id);
      const updated = [newProject, ...filtered];
      localStorage.setItem('mh_kitchen_projects', JSON.stringify(updated));
      return updated;
    });
  };

  const loadProject = (id: string) => {
    const project = savedProjects.find(p => p.id === id);
    if (project) {
      setState(s => ({
        ...s,
        ...project.state,
        currentTab: 'dashboard'
      }));
    }
  };

  const deleteProject = (id: string) => {
    setSavedProjects(prev => {
      const updated = prev.filter(p => p.id !== id);
      localStorage.setItem('mh_kitchen_projects', JSON.stringify(updated));
      return updated;
    });
  };

  const translations: Record<string, Record<'en' | 'ar', string>> = {
    'nav.dashboard': { en: 'Dashboard', ar: 'لوحة القيادة' },
    'nav.project_info': { en: 'Project Info', ar: 'معلومات المشروع' },
    'nav.pricing': { en: 'Kitchen Pricing', ar: 'تسعير المطبخ' },
    'nav.detailed_costs': { en: 'Detailed Costs', ar: 'بنود التكلفة التفصيلية' },
    'nav.full_cost': { en: 'Full Project Cost', ar: 'تكلفة المشروع الكاملة' },
    'nav.timeline': { en: 'Timeline', ar: 'الجدول الزمني' },
    'theme.dark': { en: 'Dark Mode', ar: 'الوضع الداكن' },
    'theme.light': { en: 'Light Mode', ar: 'الوضع الفاتح' },
    'lang.en': { en: 'English', ar: 'الانجليزية' },
    'lang.ar': { en: 'Arabic', ar: 'العربية' },
    'app.title': { en: 'MH Kitchen Pricing Pro', ar: 'MH تسعير المطابخ' }
  };

  const t = (key: string) => {
    return translations[key]?.[state.language] || key;
  };

  return (
    <AppContext.Provider value={{
      state, setState, sketchupSelection, updateProjectInfo, updateLabor, updateMargins,
      setLanguage, setTheme, setTab, savedProjects, saveProject, loadProject, deleteProject, t, db: databaseData
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppContext must be used within AppProvider');
  return context;
};
