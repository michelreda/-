/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useAppContext } from './AppContext';
import { Sidebar } from './components/Sidebar';
import { DashboardTab } from './components/DashboardTab';
import { ProjectInfoTab } from './components/ProjectInfoTab';
import { PricingSheetTab } from './components/PricingSheetTab';
import { DetailedCostsTab } from './components/DetailedCostsTab';
import { FullCostTab } from './components/FullCostTab';
import { TimelineTab } from './components/TimelineTab';

const MainContent: React.FC = () => {
  const { state } = useAppContext();

  const renderTab = () => {
    switch (state.currentTab) {
      case 'dashboard': return <DashboardTab />;
      case 'project_info': return <ProjectInfoTab />;
      case 'pricing': return <PricingSheetTab />;
      case 'detailed_costs': return <DetailedCostsTab />;
      case 'full_cost': return <FullCostTab />;
      case 'timeline': return <TimelineTab />;
      default: return <DashboardTab />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
      <div className="print:hidden">
        <Sidebar />
      </div>
      <main className="flex-1 overflow-y-auto p-8 print:p-0 print:overflow-visible">
        {renderTab()}
      </main>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
