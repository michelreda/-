import React, { useMemo } from 'react';
import { useAppContext } from '../AppContext';
import { calculateTotals } from '../lib/calculations';
import { DetailedCostItem } from '../types';
import { Plus, Trash2 } from 'lucide-react';

export const DetailedCostsTab: React.FC = () => {
  const { state, setState, t } = useAppContext();
  const totals = useMemo(() => calculateTotals(state), [state]);

  const updateItem = (id: string, updates: Partial<DetailedCostItem>) => {
    setState(s => ({
      ...s,
      detailedCosts: s.detailedCosts.map(item => item.id === id ? { ...item, ...updates } : item)
    }));
  };

  const addItem = () => {
    const newItem: DetailedCostItem = {
      id: Math.random().toString(36).substr(2, 9),
      name: '', description: '', quantity: 0, unit: '', pricePerUnit: 0
    };
    setState(s => ({ ...s, detailedCosts: [...s.detailedCosts, newItem] }));
  };

  const removeItem = (id: string) => {
    setState(s => ({ ...s, detailedCosts: s.detailedCosts.filter(item => item.id !== id) }));
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat(state.language === 'en' ? 'en-SA' : 'ar-SA', {
      style: 'currency', currency: 'SAR', maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="max-w-5xl animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <div className="mb-6 bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-100 dark:border-blue-900/30 text-sm text-gray-700 dark:text-gray-300">
        <p className="font-semibold mb-1">💡 {state.language === 'en' ? 'Alternative Costing:' : 'استخدم الشيت ده لو:'}</p>
        <p>{state.language === 'en' ? 'Use this if you want to detail the cost item by item (instead of using the standard pricing sheet by width/height).' : 'عايز تفصّل التكلفة بند ببند (بدل أو بجانب شيت التسعير بالعرض والارتفاع).'}</p>
      </div>

      <div className="flex justify-between items-center mb-6 border-b pb-2">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          {state.language === 'en' ? 'Detailed Kitchen Components' : 'أولاً: بنود المطبخ التفصيلية'}
        </h2>
        <button onClick={addItem} className="text-sm flex items-center gap-1 text-blue-600 hover:text-blue-700 bg-blue-50 px-3 py-1 rounded">
          <Plus size={16} /> {state.language === 'en' ? 'Add Item' : 'إضافة بند'}
        </button>
      </div>

      <div className="overflow-x-auto shadow-sm border dark:border-gray-700 rounded-lg mb-8">
        <table className="w-full text-sm text-left rtl:text-right border-collapse bg-white dark:bg-gray-800">
          <thead className="bg-blue-600 text-white">
            <tr>
              <th className="p-3 border-b dark:border-gray-700 w-12 text-center">#</th>
              <th className="p-3 border-b dark:border-gray-700">{state.language === 'en' ? 'Item Name' : 'اسم البند'}</th>
              <th className="p-3 border-b dark:border-gray-700">{state.language === 'en' ? 'Description' : 'الوصف'}</th>
              <th className="p-3 border-b dark:border-gray-700 w-24 text-center">{state.language === 'en' ? 'Quantity' : 'الكمية'}</th>
              <th className="p-3 border-b dark:border-gray-700 w-32 text-center">{state.language === 'en' ? 'Unit' : 'وحدة القياس'}</th>
              <th className="p-3 border-b dark:border-gray-700 w-32 text-center">{state.language === 'en' ? 'Price/Unit' : 'السعر للوحدة'}</th>
              <th className="p-3 border-b dark:border-gray-700 w-32 text-center">{state.language === 'en' ? 'Total' : 'التكلفة الإجمالية'}</th>
              <th className="p-3 border-b dark:border-gray-700 w-12"></th>
            </tr>
          </thead>
          <tbody>
            {state.detailedCosts.map((item, idx) => (
              <tr key={item.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                <td className="p-3 text-center text-gray-500">{idx + 1}</td>
                <td className="p-2"><input type="text" value={item.name} onChange={e => updateItem(item.id, { name: e.target.value })} className="w-full p-1 border rounded focus:ring-1 bg-transparent dark:border-gray-600" /></td>
                <td className="p-2"><input type="text" value={item.description} onChange={e => updateItem(item.id, { description: e.target.value })} className="w-full p-1 border rounded focus:ring-1 text-gray-500 text-xs bg-transparent dark:border-gray-600" /></td>
                <td className="p-2"><input type="number" value={item.quantity || ''} onChange={e => updateItem(item.id, { quantity: Number(e.target.value) })} className="w-full p-1 border rounded focus:ring-1 text-center bg-blue-50 dark:bg-blue-900/20 dark:border-gray-600" /></td>
                <td className="p-2"><input type="text" value={item.unit} onChange={e => updateItem(item.id, { unit: e.target.value })} className="w-full p-1 border rounded focus:ring-1 text-center bg-transparent dark:border-gray-600" /></td>
                <td className="p-2"><input type="number" value={item.pricePerUnit || ''} onChange={e => updateItem(item.id, { pricePerUnit: Number(e.target.value) })} className="w-full p-1 border rounded focus:ring-1 text-center bg-blue-50 dark:bg-blue-900/20 dark:border-gray-600" /></td>
                <td className="p-3 text-center font-bold text-gray-900 dark:text-white">{formatCurrency(item.quantity * item.pricePerUnit)}</td>
                <td className="p-2 text-center">
                  <button onClick={() => removeItem(item.id)} className="text-red-500 hover:text-red-700 p-1"><Trash2 size={16}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-red-700 text-white p-4 rounded-lg flex justify-between items-center mb-10 shadow-md">
        <h3 className="text-xl font-bold">{state.language === 'en' ? 'Total Detailed Costs' : 'إجمالي بنود التكلفة التفصيلية'}</h3>
        <span className="text-2xl font-bold">{formatCurrency(totals.detailedCostsTotal)}</span>
      </div>

    </div>
  );
};
