import React from 'react';
import { useAppContext } from '../AppContext';
import { LayoutDashboard, FolderKanban, Calculator, ListTodo, FileText, CalendarClock, Moon, Sun, Languages } from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { state, setTab, setTheme, setLanguage, t } = useAppContext();
  
  const navItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'nav.dashboard' },
    { id: 'project_info', icon: FolderKanban, label: 'nav.project_info' },
    { id: 'pricing', icon: Calculator, label: 'nav.pricing' },
    { id: 'detailed_costs', icon: ListTodo, label: 'nav.detailed_costs' },
    { id: 'full_cost', icon: FileText, label: 'nav.full_cost' },
    { id: 'timeline', icon: CalendarClock, label: 'nav.timeline' },
  ];

  return (
    <aside className="w-64 bg-gray-50 dark:bg-gray-900 border-l border-gray-200 dark:border-gray-800 h-screen flex flex-col transition-colors duration-200 sticky top-0 shrink-0">
      <div className="p-6 border-b border-gray-200 dark:border-gray-800">
        <h1 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <Calculator className="text-blue-600" size={24} />
          {t('app.title')}
        </h1>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = state.currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive 
                  ? 'bg-blue-600 text-white shadow-md font-medium' 
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              <Icon size={20} className={isActive ? 'text-white' : ''} />
              <span>{t(item.label)}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-200 dark:border-gray-800 space-y-2">
        <button
          onClick={() => setTheme(state.theme === 'light' ? 'dark' : 'light')}
          className="w-full flex items-center gap-3 px-4 py-2 rounded-lg text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors"
        >
          {state.theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
          <span>{state.theme === 'light' ? t('theme.dark') : t('theme.light')}</span>
        </button>
        <button
          onClick={() => setLanguage(state.language === 'en' ? 'ar' : 'en')}
          className="w-full flex items-center gap-3 px-4 py-2 rounded-lg text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors"
        >
          <Languages size={20} />
          <span>{state.language === 'en' ? t('lang.ar') : t('lang.en')}</span>
        </button>
      </div>
    </aside>
  );
};
