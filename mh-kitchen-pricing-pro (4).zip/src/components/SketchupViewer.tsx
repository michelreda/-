import React from 'react';
import { useAppContext } from '../AppContext';

export const SketchupViewer: React.FC = () => {
  const { sketchupSelection, state } = useAppContext();

  if (!sketchupSelection) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-8 text-center flex flex-col items-center justify-center min-h-[300px] h-full shadow-sm">
        <div className="w-16 h-16 bg-blue-50 dark:bg-blue-900/20 rounded-full mb-4 flex items-center justify-center text-blue-500">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
        </div>
        <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">
          {state.language === 'en' ? 'Awaiting SketchUp Selection' : 'في انتظار تحديد سكيتش أب'}
        </h3>
        <p className="text-gray-500 dark:text-gray-400 text-sm max-w-[250px]">
          {state.language === 'en' 
            ? 'Select a component in SketchUp to preview its 2D schematic scale.' 
            : 'قم بتحديد عنصر في سكيتش أب لمعاينة مخططه الهندسي.'}
        </p>
      </div>
    );
  }

  const { width, depth, height, name } = sketchupSelection;
  
  // Calculate relative sizes for 2D schematic drawing
  const maxDimFront = Math.max(width, height, 1);
  const maxDimTop = Math.max(width, depth, 1);
  
  // Fit within the available canvas width/height (approx 180px max)
  const scaleFront = 140 / maxDimFront;
  const scaleTop = 140 / maxDimTop;
  
  const drawFrontW = width * scaleFront;
  const drawFrontH = height * scaleFront;
  
  const drawTopW = width * scaleTop;
  const drawTopD = depth * scaleTop;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 shadow-sm h-full flex flex-col">
      <div className="flex justify-between items-start mb-6 border-b border-gray-100 dark:border-gray-700 pb-4">
        <div>
          <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
            {name || (state.language === 'en' ? 'Selected Component' : 'العنصر المحدد')}
          </h3>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 uppercase tracking-wider font-semibold">
            {state.language === 'en' ? '2D Schematic Overlay' : 'مخطط 2D هندسي'}
          </p>
        </div>
        <div className="bg-blue-50 dark:bg-blue-900/20 px-2 py-1 rounded text-blue-700 dark:text-blue-400 font-mono text-xs font-bold border border-blue-100 dark:border-blue-800">
          W:{width} × D:{depth} × H:{height} cm
        </div>
      </div>

      <div className="flex-1 grid grid-cols-2 gap-6 items-center">
        
        {/* Front View */}
        <div className="flex flex-col items-center justify-center">
          <span className="text-xs font-medium text-gray-500 mb-4">{state.language === 'en' ? 'FRONT VIEW' : 'المسقط الأمامي'}</span>
          <div className="relative flex justify-center items-center w-[160px] h-[160px] bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-700">
            <div className="absolute border-2 border-blue-500 bg-blue-500/10 flex items-center justify-center shadow-sm"
                 style={{ width: drawFrontW, height: drawFrontH }}>
              {/* Internal grid lines for cabinetry feel */}
              <div className="absolute inset-0 border border-blue-500/20 m-1"></div>
              {/* Width Label */}
              <div className="absolute -bottom-5 text-[10px] font-mono text-gray-600 dark:text-gray-400 whitespace-nowrap">
                {width} cm
              </div>
              {/* Height Label */}
              <div className="absolute -left-8 top-1/2 -translate-y-1/2 text-[10px] font-mono text-gray-600 dark:text-gray-400 whitespace-nowrap -rotate-90 origin-center">
                {height} cm
              </div>
            </div>
          </div>
        </div>

        {/* Top View */}
        <div className="flex flex-col items-center justify-center">
          <span className="text-xs font-medium text-gray-500 mb-4">{state.language === 'en' ? 'TOP VIEW' : 'المسقط الأفقي'}</span>
          <div className="relative flex justify-center items-center w-[160px] h-[160px] bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-700">
            <div className="absolute border-2 border-emerald-500 bg-emerald-500/10 flex items-center justify-center shadow-sm"
                 style={{ width: drawTopW, height: drawTopD }}>
              {/* Internal grid lines for cabinetry feel */}
              <div className="absolute inset-0 border border-emerald-500/20 m-1"></div>
              <div className="absolute top-0 left-0 right-0 h-1 bg-emerald-500/30"></div> {/* Front edge indicator */}
              {/* Width Label */}
              <div className="absolute -bottom-5 text-[10px] font-mono text-gray-600 dark:text-gray-400 whitespace-nowrap">
                {width} cm
              </div>
              {/* Depth Label */}
              <div className="absolute -right-8 top-1/2 -translate-y-1/2 text-[10px] font-mono text-gray-600 dark:text-gray-400 whitespace-nowrap rotate-90 origin-center">
                {depth} cm
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
