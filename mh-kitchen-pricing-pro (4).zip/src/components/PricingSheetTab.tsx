import React, { useMemo } from 'react';
import { useAppContext } from '../AppContext';
import { calculateTotals, calculateUnitArea, calculateUnitTotal } from '../lib/calculations';
import { UnitInput, AccessoryInput, UnitCategory } from '../types';
import { Plus, Trash2, Maximize, Component as ComponentIcon } from 'lucide-react';
import { readDimensionsFromSketchup } from '../lib/sketchup';
import { SketchupViewer } from './SketchupViewer';

export const PricingSheetTab: React.FC = () => {
  const { state, setState, sketchupSelection, t } = useAppContext();
  const totals = useMemo(() => calculateTotals(state), [state]);

  const updateUnit = (id: string, updates: Partial<UnitInput>) => {
    setState(s => ({
      ...s,
      units: s.units.map(u => u.id === id ? { ...u, ...updates } : u)
    }));
  };

  const addUnit = (category: UnitCategory, dims?: { width: number, depth: number, height: number }) => {
    let w = 0, h = 0;
    if (dims) {
      if (category === 'marble') {
        w = dims.width;
        h = dims.depth; // marble depth goes into height column
      } else if (category === 'side') {
        // A side panel usually has its depth as the "Width" in cutting lists, and height as "Height". The thickness is width.
        // We'll take the largest horizontal dimension as Width to be safe, or just map depth to width.
        w = Math.max(dims.width, dims.depth);
        h = dims.height;
      } else {
        w = dims.width;
        h = dims.height;
      }
    }
    const newUnit: UnitInput = {
      id: Math.random().toString(36).substr(2, 9),
      category,
      width1: w, width2: 0, width3: 0, width4: 0,
      height: h,
      pricePerMeter: 0
    };
    setState(s => ({ ...s, units: [...s.units, newUnit] }));
  };

  const readFromSketchUp = async (category: UnitCategory) => {
    try {
      const dims = await readDimensionsFromSketchup();
      addUnit(category, dims);
    } catch (e: any) {
      alert(e.message);
    }
  };

  const removeUnit = (id: string) => {
    setState(s => ({ ...s, units: s.units.filter(u => u.id !== id) }));
  };

  const updateAccessory = (id: string, updates: Partial<AccessoryInput>) => {
    setState(s => ({
      ...s,
      accessories: s.accessories.map(a => a.id === id ? { ...a, ...updates } : a)
    }));
  };

  const addAccessory = () => {
    const newAcc: AccessoryInput = {
      id: Math.random().toString(36).substr(2, 9),
      name: '', notes: '', quantity: 0, pricePerUnit: 0
    };
    setState(s => ({ ...s, accessories: [...s.accessories, newAcc] }));
  };

  const removeAccessory = (id: string) => {
    setState(s => ({ ...s, accessories: s.accessories.filter(a => a.id !== id) }));
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat(state.language === 'en' ? 'en-SA' : 'ar-SA', {
      style: 'currency', currency: 'SAR', maximumFractionDigits: 0
    }).format(amount);
  };

  const renderUnitTable = (category: UnitCategory, title: string) => {
    const units = state.units.filter(u => u.category === category);
    const categoryTotal = units.reduce((acc, u) => acc + calculateUnitTotal(u), 0);

    return (
      <div className="mb-10 overflow-hidden bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <ComponentIcon size={20} className="text-blue-500" />
            {title}
          </h3>
          <div className="flex gap-2 mt-3 sm:mt-0">
            <button onClick={() => addUnit(category)} className="text-sm flex items-center gap-1 text-blue-700 hover:text-white hover:bg-blue-600 bg-blue-50 px-4 py-2 rounded-lg border border-blue-200 transition-colors">
              <Plus size={16} /> {state.language === 'en' ? 'Add Row' : 'إضافة صف'}
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right border-collapse">
            <thead className="bg-gray-50/50 dark:bg-gray-900/20 text-gray-600 dark:text-gray-300 border-b border-gray-100 dark:border-gray-700">
              <tr>
                <th className="p-3 font-semibold">{state.language === 'en' ? 'W1' : 'عرض 1'}</th>
                <th className="p-3 font-semibold">{state.language === 'en' ? 'W2' : 'عرض 2'}</th>
                <th className="p-3 font-semibold">{state.language === 'en' ? 'W3' : 'عرض 3'}</th>
                <th className="p-3 font-semibold">{state.language === 'en' ? 'W4' : 'عرض 4'}</th>
                <th className="p-3 font-semibold text-center border-x border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/30">{state.language === 'en' ? 'Total W (m)' : 'الكلي (م)'}</th>
                <th className="p-3 font-semibold">{category === 'marble' ? (state.language === 'en' ? 'Depth (cm)' : 'العمق (سم)') : (state.language === 'en' ? 'Height (cm)' : 'الارتفاع (سم)')}</th>
                <th className="p-3 font-semibold text-center border-l border-gray-100 dark:border-gray-700">{state.language === 'en' ? 'Area (m²)' : 'المساحة (م²)'}</th>
                <th className="p-3 font-semibold">{state.language === 'en' ? 'Price/m²' : 'سعر المتر'}</th>
                <th className="p-3 font-semibold text-center border-l border-gray-100 dark:border-gray-700">{state.language === 'en' ? 'Total' : 'الإجمالي'}</th>
                <th className="p-3 w-12"></th>
              </tr>
            </thead>
            <tbody>
              {units.length === 0 ? (
                <tr>
                  <td colSpan={10} className="p-6 text-center text-gray-400">
                    {state.language === 'en' ? 'No units added yet.' : 'لم يتم إضافة وحدات بعد.'}
                  </td>
                </tr>
              ) : units.map(u => {
                const totalW = (u.width1 || 0) + (u.width2 || 0) + (u.width3 || 0) + (u.width4 || 0);
                const area = calculateUnitArea(u);
                const total = calculateUnitTotal(u);
                return (
                  <tr key={u.id} className="border-b border-gray-50 dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-800/80 transition-colors">
                    <td className="p-2"><input type="number" value={u.width1 || ''} onChange={e => updateUnit(u.id, { width1: Number(e.target.value) })} className="w-16 p-2 bg-gray-100 dark:bg-gray-900 border-none rounded focus:ring-2 focus:ring-blue-500 text-center" /></td>
                    <td className="p-2"><input type="number" value={u.width2 || ''} onChange={e => updateUnit(u.id, { width2: Number(e.target.value) })} className="w-16 p-2 bg-gray-100 dark:bg-gray-900 border-none rounded focus:ring-2 focus:ring-blue-500 text-center" /></td>
                    <td className="p-2"><input type="number" value={u.width3 || ''} onChange={e => updateUnit(u.id, { width3: Number(e.target.value) })} className="w-16 p-2 bg-gray-100 dark:bg-gray-900 border-none rounded focus:ring-2 focus:ring-blue-500 text-center" /></td>
                    <td className="p-2"><input type="number" value={u.width4 || ''} onChange={e => updateUnit(u.id, { width4: Number(e.target.value) })} className="w-16 p-2 bg-gray-100 dark:bg-gray-900 border-none rounded focus:ring-2 focus:ring-blue-500 text-center" /></td>
                    <td className="p-2 border-x border-gray-100 dark:border-gray-700 font-mono text-center font-medium bg-gray-50 dark:bg-gray-900/30">{(totalW / 100).toFixed(2)}</td>
                    <td className="p-2"><input type="number" value={u.height || ''} onChange={e => updateUnit(u.id, { height: Number(e.target.value) })} className="w-16 p-2 bg-gray-100 dark:bg-gray-900 border-none rounded focus:ring-2 focus:ring-blue-500 text-center" /></td>
                    <td className="p-2 border-l border-gray-100 dark:border-gray-700 font-mono text-center font-medium">{area.toFixed(2)}</td>
                    <td className="p-2"><input type="number" value={u.pricePerMeter || ''} onChange={e => updateUnit(u.id, { pricePerMeter: Number(e.target.value) })} className="w-20 p-2 bg-gray-100 dark:bg-gray-900 border-none rounded focus:ring-2 focus:ring-blue-500 text-center" /></td>
                    <td className="p-2 border-l border-gray-100 dark:border-gray-700 font-bold text-center text-blue-700 dark:text-blue-400">{formatCurrency(total)}</td>
                    <td className="p-2 text-center">
                      <button onClick={() => removeUnit(u.id)} className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors"><Trash2 size={16}/></button>
                    </td>
                  </tr>
                );
              })}
              <tr className="bg-gray-50 dark:bg-gray-800/80 font-bold border-t border-gray-200 dark:border-gray-600">
                <td colSpan={8} className="p-4 text-left rtl:text-right text-gray-700 dark:text-gray-300">
                  {state.language === 'en' ? 'Section Subtotal' : 'إجمالي القسم'}
                </td>
                <td colSpan={2} className="p-4 text-center text-lg text-blue-700 dark:text-blue-400">
                  {formatCurrency(categoryTotal)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-6xl animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-1">
          <SketchupViewer />
        </div>
        
        <div className="lg:col-span-2">
          {sketchupSelection && (
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-blue-200 dark:border-blue-800/50 p-6 flex flex-col justify-center h-full">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                {state.language === 'en' ? 'Add this component as:' : 'إضافة هذا العنصر كـ:'}
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <button onClick={() => addUnit('base', sketchupSelection)} className="p-4 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white rounded-lg border border-blue-200 dark:border-blue-800 transition-all text-center font-medium">
                  {state.language === 'en' ? 'Base Unit' : 'وحدة سفلية'}
                </button>
                <button onClick={() => addUnit('wall', sketchupSelection)} className="p-4 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white rounded-lg border border-blue-200 dark:border-blue-800 transition-all text-center font-medium">
                  {state.language === 'en' ? 'Wall Unit' : 'وحدة علوية'}
                </button>
                <button onClick={() => addUnit('tall', sketchupSelection)} className="p-4 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white rounded-lg border border-blue-200 dark:border-blue-800 transition-all text-center font-medium">
                  {state.language === 'en' ? 'Tall Unit' : 'دولاب'}
                </button>
                <button onClick={() => addUnit('side', sketchupSelection)} className="p-4 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white rounded-lg border border-blue-200 dark:border-blue-800 transition-all text-center font-medium">
                  {state.language === 'en' ? 'Side Panel' : 'جنب'}
                </button>
                <button onClick={() => addUnit('marble', sketchupSelection)} className="p-4 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white rounded-lg border border-blue-200 dark:border-blue-800 transition-all text-center font-medium">
                  {state.language === 'en' ? 'Marble' : 'رخام'}
                </button>
              </div>
            </div>
          )}
          {!sketchupSelection && (
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 flex flex-col justify-center h-full items-center text-center">
              <div className="text-gray-400 dark:text-gray-500 mb-2">
                <Maximize size={32} />
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">
                {state.language === 'en' ? 'Live SketchUp Sync' : 'مزامنة حية مع سكيتش أب'}
              </h3>
              <p className="text-gray-500 dark:text-gray-400 max-w-sm">
                {state.language === 'en' 
                  ? 'Select any component in your SketchUp model to see its dimensions and add it to your pricing sheet automatically.' 
                  : 'قم بتحديد أي عنصر في نموذج سكيتش أب لرؤية أبعاده وإضافته إلى جدول التسعير تلقائياً.'}
              </p>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-4 mb-6 pb-2 border-b border-gray-200 dark:border-gray-700">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          {state.language === 'en' ? 'Wood Units' : 'وحدات الخشب'}
        </h2>
      </div>

      {renderUnitTable('base', state.language === 'en' ? 'Base Units' : 'الوحدات السفلية')}
      {renderUnitTable('wall', state.language === 'en' ? 'Wall Units' : 'الوحدات العلوية')}
      {renderUnitTable('tall', state.language === 'en' ? 'Tall Units & Pantries' : 'الدواليب و الأدراج')}
      {renderUnitTable('side', state.language === 'en' ? 'Side Panels' : 'الأجناب')}

      <div className="flex items-center gap-4 mt-12 mb-6 pb-2 border-b border-gray-200 dark:border-gray-700">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex-1">
          {state.language === 'en' ? 'Accessories & Hardware' : 'الإكسسوارات (هارد وير)'}
        </h2>
        <button onClick={addAccessory} className="text-sm flex items-center gap-1 text-blue-700 hover:text-white hover:bg-blue-600 bg-blue-50 px-4 py-2 rounded-lg border border-blue-200 transition-colors shadow-sm">
          <Plus size={16} /> {state.language === 'en' ? 'Add Accessory' : 'إضافة صنف'}
        </button>
      </div>

      <div className="mb-10 overflow-hidden bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right border-collapse">
            <thead className="bg-gray-50/50 dark:bg-gray-900/20 text-gray-600 dark:text-gray-300 border-b border-gray-100 dark:border-gray-700">
              <tr>
                <th className="p-3 font-semibold">{state.language === 'en' ? 'Item' : 'الصنف'}</th>
                <th className="p-3 font-semibold w-1/3">{state.language === 'en' ? 'Notes' : 'ملاحظات'}</th>
                <th className="p-3 font-semibold w-24 text-center">{state.language === 'en' ? 'Quantity' : 'الكمية'}</th>
                <th className="p-3 font-semibold w-32 text-center">{state.language === 'en' ? 'Price/Unit' : 'سعر القطعة'}</th>
                <th className="p-3 font-semibold w-32 text-center border-l border-gray-100 dark:border-gray-700">{state.language === 'en' ? 'Total' : 'الإجمالي'}</th>
                <th className="p-3 w-12"></th>
              </tr>
            </thead>
            <tbody>
              {state.accessories.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-gray-400">
                    {state.language === 'en' ? 'No accessories added.' : 'لم يتم إضافة إكسسوارات.'}
                  </td>
                </tr>
              ) : state.accessories.map(a => (
                <tr key={a.id} className="border-b border-gray-50 dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-800/80 transition-colors">
                  <td className="p-2"><input type="text" value={a.name} onChange={e => updateAccessory(a.id, { name: e.target.value })} className="w-full p-2 bg-gray-100 dark:bg-gray-900 border-none rounded focus:ring-2 focus:ring-blue-500" placeholder={state.language === 'en' ? 'Item name...' : 'اسم الصنف...'} /></td>
                  <td className="p-2"><input type="text" value={a.notes} onChange={e => updateAccessory(a.id, { notes: e.target.value })} className="w-full p-2 bg-yellow-50/50 dark:bg-yellow-900/10 border-none rounded focus:ring-2 focus:ring-blue-500" placeholder={state.language === 'en' ? 'Notes...' : 'ملاحظات...'} /></td>
                  <td className="p-2"><input type="number" value={a.quantity || ''} onChange={e => updateAccessory(a.id, { quantity: Number(e.target.value) })} className="w-full p-2 bg-gray-100 dark:bg-gray-900 border-none rounded focus:ring-2 focus:ring-blue-500 text-center" /></td>
                  <td className="p-2"><input type="number" value={a.pricePerUnit || ''} onChange={e => updateAccessory(a.id, { pricePerUnit: Number(e.target.value) })} className="w-full p-2 bg-gray-100 dark:bg-gray-900 border-none rounded focus:ring-2 focus:ring-blue-500 text-center" /></td>
                  <td className="p-2 border-l border-gray-100 dark:border-gray-700 font-bold text-center text-blue-700 dark:text-blue-400">{formatCurrency(a.quantity * a.pricePerUnit)}</td>
                  <td className="p-2 text-center">
                    <button onClick={() => removeAccessory(a.id)} className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors"><Trash2 size={16}/></button>
                  </td>
                </tr>
              ))}
              <tr className="bg-gray-50 dark:bg-gray-800/80 font-bold border-t border-gray-200 dark:border-gray-600">
                <td colSpan={4} className="p-4 text-left rtl:text-right text-gray-700 dark:text-gray-300">
                  {state.language === 'en' ? 'Accessories Total' : 'إجمالي الإكسسوارات'}
                </td>
                <td colSpan={2} className="p-4 text-center text-lg text-blue-700 dark:text-blue-400">
                  {formatCurrency(totals.totalAccessories)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex items-center gap-4 mt-12 mb-6 pb-2 border-b border-gray-200 dark:border-gray-700">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          {state.language === 'en' ? 'Marble Sections' : 'قطع الرخام'}
        </h2>
      </div>

      {renderUnitTable('marble', state.language === 'en' ? 'Marble Sections' : 'قطع الرخام')}

    </div>
  );
};
