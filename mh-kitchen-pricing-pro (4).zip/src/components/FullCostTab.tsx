import React, { useMemo } from 'react';
import { useAppContext } from '../AppContext';
import { calculateTotals } from '../lib/calculations';
import { Printer, Download } from 'lucide-react';

export const FullCostTab: React.FC = () => {
  const { state, updateLabor, updateMargins, t } = useAppContext();
  const totals = useMemo(() => calculateTotals(state), [state]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat(state.language === 'en' ? 'en-SA' : 'ar-SA', {
      style: 'currency', currency: 'SAR', maximumFractionDigits: 0
    }).format(amount);
  };

  const exportToCSV = () => {
    const rows = [
      ['Category', 'Name/Description', 'Quantity/Area', 'Unit Price', 'Total'],
      ...state.units.map(u => [
        'Unit: ' + u.category, 
        `${u.width1}+${u.width2}+${u.width3}+${u.width4} x ${u.height}`, 
        ((((u.width1||0) + (u.width2||0) + (u.width3||0) + (u.width4||0))/100) * (u.height/100)).toFixed(2), 
        u.pricePerMeter, 
        ((((u.width1||0) + (u.width2||0) + (u.width3||0) + (u.width4||0))/100) * (u.height/100) * u.pricePerMeter).toFixed(2)
      ]),
      ...state.accessories.map(a => ['Accessory', a.name, a.quantity, a.pricePerUnit, a.quantity * a.pricePerUnit]),
      ...state.detailedCosts.map(d => ['Detailed Cost', d.name, d.quantity, d.pricePerUnit, d.quantity * d.pricePerUnit]),
      ['Labor', 'Carpentry', '', '', state.labor.carpentry],
      ['Labor', 'Installation', '', '', state.labor.installation],
      ['Labor', 'Transport', '', '', state.labor.transport],
      ['Summary', 'Contract Total (Wood+Acc+Marble)', '', '', totals.contractTotal],
      ['Summary', 'Profit Value', '', '', totals.profitValue],
      ['Summary', 'Contingency Value', '', '', totals.contingencyValue],
      ['Summary', 'Final Price', '', '', totals.finalPrice],
    ];

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + rows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Project_${state.projectInfo.projectNumber || 'Export'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-4xl animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4 print:hidden">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          {state.language === 'en' ? 'Full Project Cost & Pricing' : 'نموذج تكلفة وتسعير المشروع الكامل'}
        </h2>
        <div className="flex gap-2">
          <button onClick={exportToCSV} className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors">
            <Download size={18} /> {state.language === 'en' ? 'Export CSV' : 'تصدير CSV'}
          </button>
          <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 transition-colors">
            <Printer size={18} /> {state.language === 'en' ? 'Print / PDF' : 'طباعة / حفظ PDF'}
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 md:p-8 mb-8 print:shadow-none print:border-none print:p-0">
        
        {/* Header Info */}
        <div className="grid grid-cols-2 gap-4 mb-8 bg-orange-50 dark:bg-orange-900/10 p-4 rounded-lg">
          <div>
            <p className="text-sm text-gray-500">{state.language === 'en' ? 'Client Name' : 'اسم العميل'}</p>
            <p className="font-bold text-lg text-gray-900 dark:text-white">{state.projectInfo.customerName || '-'}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">{state.language === 'en' ? 'Project Name/No' : 'اسم المشروع'}</p>
            <p className="font-bold text-lg text-gray-900 dark:text-white">{state.projectInfo.projectNumber || '-'}</p>
          </div>
        </div>

        {/* Section 1: Materials */}
        <div className="mb-8 print-break-inside-avoid">
          <h3 className="text-lg font-bold text-white bg-blue-600 px-4 py-2 rounded-t-lg">
            {state.language === 'en' ? 'First: Materials' : 'أولاً: الخامات'}
          </h3>
          <table className="w-full text-sm text-left rtl:text-right border-collapse border border-t-0 dark:border-gray-700">
            <tbody>
              <tr className="border-b dark:border-gray-700 bg-blue-50/50 dark:bg-blue-900/10">
                <td className="p-3 w-1/2 font-medium text-blue-800 dark:text-blue-300">
                  {state.language === 'en' ? 'Labor Percentage (Overrides Manual)' : 'نسبة العمالة المئوية (يلغي الإدخال اليدوي)'}
                </td>
                <td className="p-3 w-1/4 text-center">
                  <div className="flex items-center justify-center">
                    <input type="number" value={state.margins.laborPercent || ''} onChange={e => updateMargins({laborPercent: Number(e.target.value)})} className="w-16 p-2 bg-blue-100 dark:bg-blue-900/40 rounded-l text-center font-bold text-blue-900 dark:text-blue-200" placeholder="0" />
                    <span className="bg-blue-200 dark:bg-blue-800 p-2 rounded-r font-bold text-blue-900 dark:text-blue-200">%</span>
                  </div>
                </td>
                <td className="p-3 text-xs text-blue-600/70 dark:text-blue-400">
                  {state.language === 'en' ? 'If set > 0, manual inputs below are ignored' : 'إذا كانت النسبة أكبر من 0، يتم تجاهل الإدخالات اليدوية'}
                </td>
              </tr>

              <tr className="border-b dark:border-gray-700">
                <td className="p-3 w-1/2">{state.language === 'en' ? 'Wood (Units) - From Pricing Sheet' : 'خشب (وحدات) - من شيت التسعير'}</td>
                <td className="p-3 w-1/4 text-center font-mono">{formatCurrency(totals.totalWood)}</td>
                <td className="p-3 text-xs text-gray-500">{state.language === 'en' ? 'Auto-calculated' : 'قيمة تلقائية'}</td>
              </tr>
              <tr className="border-b dark:border-gray-700">
                <td className="p-3">{state.language === 'en' ? 'Accessories / Hardware' : 'إكسسوارات / هارد وير'}</td>
                <td className="p-3 text-center font-mono">{formatCurrency(totals.totalAccessories)}</td>
                <td className="p-3 text-xs text-gray-500">{state.language === 'en' ? 'Auto-calculated' : 'قيمة تلقائية'}</td>
              </tr>
              <tr className="border-b dark:border-gray-700">
                <td className="p-3">{state.language === 'en' ? 'Marble' : 'رخام - من شيت التسعير'}</td>
                <td className="p-3 text-center font-mono">{formatCurrency(totals.totalMarble)}</td>
                <td className="p-3 text-xs text-gray-500">{state.language === 'en' ? 'Auto-calculated' : 'قيمة تلقائية'}</td>
              </tr>
              <tr className="border-b dark:border-gray-700 bg-blue-50 dark:bg-blue-900/10">
                <td className="p-3">
                  {state.language === 'en' ? 'Custom Items (from Detailed Costs)' : 'بنود تفصيلية إضافية - من شيت التكلفة التفصيلية'}
                </td>
                <td className="p-3 text-center">
                  <input type="number" value={state.labor.additionalMaterials || ''} onChange={e => updateLabor({additionalMaterials: Number(e.target.value)})} className="w-24 p-1 text-center bg-white dark:bg-gray-800 border rounded" placeholder={totals.detailedCostsTotal.toString()}/>
                </td>
                <td className="p-3 text-xs text-gray-500 text-orange-600 dark:text-orange-400">
                  {state.language === 'en' ? '⚠️ Ensure no duplication with sheet 1' : '⚠️ لو بتستخدم شيت التسعير، خلي ده 0 تفادياً للتكرار'}
                </td>
              </tr>
              <tr className="bg-orange-100 dark:bg-orange-900/20 font-bold">
                <td className="p-3">{state.language === 'en' ? 'Total Materials' : 'إجمالي الخامات'}</td>
                <td className="p-3 text-center text-lg">{formatCurrency((state.labor.additionalMaterials || 0) + totals.contractTotal)}</td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Section 2: Labor & Manufacturing */}
        <div className="mb-8 print-break-inside-avoid">
          <h3 className="text-lg font-bold text-white bg-blue-600 px-4 py-2 rounded-t-lg">
            {state.language === 'en' ? 'Second: Labor & Manufacturing' : 'ثانياً: الأيدي العاملة والتصنيع'}
          </h3>
          <table className="w-full text-sm text-left rtl:text-right border-collapse border border-t-0 dark:border-gray-700">
            <tbody>
              <tr className="border-b dark:border-gray-700">
                <td className="p-3 w-1/2">{state.language === 'en' ? 'Carpentry / Manufacturing Fee' : 'أجرة النجارة / التصنيع'}</td>
                <td className="p-3 w-1/4 text-center">
                  <input type="number" value={state.labor.carpentry || ''} onChange={e => updateLabor({carpentry: Number(e.target.value)})} className="w-full p-2 bg-blue-50 dark:bg-blue-900/20 rounded text-center" />
                </td>
                <td></td>
              </tr>
              <tr className="border-b dark:border-gray-700">
                <td className="p-3">{state.language === 'en' ? 'Installation Fee' : 'أجرة التركيب'}</td>
                <td className="p-3 text-center">
                  <input type="number" value={state.labor.installation || ''} onChange={e => updateLabor({installation: Number(e.target.value)})} className="w-full p-2 bg-blue-50 dark:bg-blue-900/20 rounded text-center" />
                </td>
                <td></td>
              </tr>
              <tr className="border-b dark:border-gray-700">
                <td className="p-3">{state.language === 'en' ? 'Transport & Shipping' : 'مصاريف نقل وشحن'}</td>
                <td className="p-3 text-center">
                  <input type="number" value={state.labor.transport || ''} onChange={e => updateLabor({transport: Number(e.target.value)})} className="w-full p-2 bg-blue-50 dark:bg-blue-900/20 rounded text-center" />
                </td>
                <td></td>
              </tr>
              <tr className="border-b dark:border-gray-700">
                <td className="p-3">{state.language === 'en' ? 'Others' : 'أخرى'}</td>
                <td className="p-3 text-center">
                  <input type="number" value={state.labor.others || ''} onChange={e => updateLabor({others: Number(e.target.value)})} className="w-full p-2 bg-blue-50 dark:bg-blue-900/20 rounded text-center" />
                </td>
                <td></td>
              </tr>
              <tr className="bg-orange-100 dark:bg-orange-900/20 font-bold">
                <td className="p-3">{state.language === 'en' ? 'Total Labor & Mfg' : 'إجمالي الأيدي العاملة والتصنيع'}</td>
                <td className="p-3 text-center text-lg">{formatCurrency(totals.laborTotal)}</td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="bg-gray-100 dark:bg-gray-800 p-4 border dark:border-gray-700 rounded-lg mb-8 flex justify-between items-center font-bold">
          <span>{state.language === 'en' ? 'Total Basic Cost (Materials + Labor)' : 'إجمالي التكلفة الأساسية (خامات + أيدي عاملة)'}</span>
          <span className="text-xl">{formatCurrency(totals.basicCost)}</span>
        </div>

        {/* Section 3: Margins */}
        <div className="mb-8 print-break-inside-avoid">
          <h3 className="text-lg font-bold text-white bg-blue-600 px-4 py-2 rounded-t-lg">
            {state.language === 'en' ? 'Third: Profit Margin & Contingency' : 'ثالثاً: هامش الربح واحتياطي الطوارئ'}
          </h3>
          <table className="w-full text-sm text-left rtl:text-right border-collapse border border-t-0 dark:border-gray-700">
            <tbody>
              <tr className="border-b dark:border-gray-700">
                <td className="p-3 w-1/2">{state.language === 'en' ? 'Profit Margin %' : 'نسبة هامش الربح'}</td>
                <td className="p-3 w-1/4 text-center">
                  <div className="flex items-center justify-center">
                    <input type="number" value={state.margins.profitPercent || ''} onChange={e => updateMargins({profitPercent: Number(e.target.value)})} className="w-16 p-2 bg-blue-50 dark:bg-blue-900/20 rounded-l text-center" />
                    <span className="bg-gray-200 dark:bg-gray-700 p-2 rounded-r">%</span>
                  </div>
                </td>
                <td className="p-3 text-xs text-gray-500">{state.language === 'en' ? 'Adjust per project (15-30%)' : 'عدّل النسبة حسب المشروع (غالباً 15%-30%)'}</td>
              </tr>
              <tr className="border-b dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                <td className="p-3">{state.language === 'en' ? 'Profit Value' : 'قيمة هامش الربح'}</td>
                <td className="p-3 text-center font-mono">{formatCurrency(totals.profitValue)}</td>
                <td></td>
              </tr>
              <tr className="border-b dark:border-gray-700">
                <td className="p-3">{state.language === 'en' ? 'Contingency Reserve %' : 'نسبة احتياطي الطوارئ'}</td>
                <td className="p-3 text-center">
                  <div className="flex items-center justify-center">
                    <input type="number" value={state.margins.contingencyPercent || ''} onChange={e => updateMargins({contingencyPercent: Number(e.target.value)})} className="w-16 p-2 bg-blue-50 dark:bg-blue-900/20 rounded-l text-center" />
                    <span className="bg-gray-200 dark:bg-gray-700 p-2 rounded-r">%</span>
                  </div>
                </td>
                <td className="p-3 text-xs text-gray-500">{state.language === 'en' ? '10-15% buffer for delays/prices' : '10%-15% تحسباً لأي تأخير أو زيادة أسعار خامات'}</td>
              </tr>
              <tr className="border-b dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                <td className="p-3">{state.language === 'en' ? 'Contingency Value' : 'قيمة احتياطي الطوارئ'}</td>
                <td className="p-3 text-center font-mono">{formatCurrency(totals.contingencyValue)}</td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Final */}
        <div className="bg-red-700 text-white p-6 rounded-xl flex justify-between items-center shadow-xl mb-8">
          <h2 className="text-2xl font-bold">{state.language === 'en' ? 'Final Quoted Price' : 'السعر النهائي المعروض على العميل'}</h2>
          <span className="text-4xl font-black">{formatCurrency(totals.finalPrice)}</span>
        </div>

        <div className="flex justify-between items-center text-sm border-t dark:border-gray-700 pt-4">
          <div className="flex gap-4">
            <div>
              <span className="text-gray-500 block">{state.language === 'en' ? 'Expected Net Profit' : 'صافي الربح المتوقع'}</span>
              <span className="font-bold text-green-600 dark:text-green-400">{formatCurrency(totals.netProfit)}</span>
            </div>
            <div>
              <span className="text-gray-500 block">{state.language === 'en' ? 'Net Profit Margin' : 'نسبة الربح الصافي'}</span>
              <span className="font-bold text-green-600 dark:text-green-400">{totals.netProfitPercent.toFixed(1)}%</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
