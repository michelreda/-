import React from 'react';
import { useAppContext } from '../AppContext';
import { TimelineTask } from '../types';

export const TimelineTab: React.FC = () => {
  const { state, setState, t } = useAppContext();

  const updateTask = (id: string, updates: Partial<TimelineTask>) => {
    setState(s => ({
      ...s,
      timeline: s.timeline.map(task => task.id === id ? { ...task, ...updates } : task)
    }));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400';
      case 'in_progress': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-400';
    }
  };

  return (
    <div className="max-w-5xl animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      
      <div className="bg-blue-600 text-white p-6 rounded-t-xl text-center print:bg-transparent print:text-black print:p-0 print:mb-4">
        <h2 className="text-2xl font-bold mb-2">
          {state.language === 'en' ? 'Project Timeline' : 'الجدول الزمني للمشروع'}
        </h2>
        <div className="flex justify-center gap-8 opacity-90 text-sm">
          <p>{state.language === 'en' ? 'Project:' : 'اسم المشروع:'} {state.projectInfo.projectNumber}</p>
          <p>{state.language === 'en' ? 'Client:' : 'اسم العميل:'} {state.projectInfo.customerName}</p>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-b-xl shadow-sm border border-t-0 dark:border-gray-700 overflow-hidden print:shadow-none print:border-none">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right border-collapse">
            <thead className="bg-gray-50 dark:bg-gray-900 border-b dark:border-gray-700 text-gray-700 dark:text-gray-300">
              <tr>
                <th className="p-4">{state.language === 'en' ? 'Phase' : 'المرحلة'}</th>
                <th className="p-4 w-32">{state.language === 'en' ? 'Start Date' : 'تاريخ البداية'}</th>
                <th className="p-4 w-32">{state.language === 'en' ? 'End Date' : 'تاريخ النهاية'}</th>
                <th className="p-4 w-24 text-center">{state.language === 'en' ? 'Duration (Days)' : 'المدة (أيام)'}</th>
                <th className="p-4 w-32 text-center">{state.language === 'en' ? 'Status' : 'الحالة'}</th>
                <th className="p-4">{state.language === 'en' ? 'Notes' : 'ملاحظات'}</th>
              </tr>
            </thead>
            <tbody>
              {state.timeline.map((task) => (
                <tr key={task.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <td className="p-4 font-medium text-gray-900 dark:text-white">
                    <input 
                      type="text" 
                      value={task.phase} 
                      onChange={e => updateTask(task.id, { phase: e.target.value })} 
                      className="w-full bg-transparent border-none focus:ring-0 p-0 font-medium"
                    />
                  </td>
                  <td className="p-3">
                    <input 
                      type="date" 
                      value={task.startDate} 
                      onChange={e => updateTask(task.id, { startDate: e.target.value })} 
                      className="w-full p-2 border rounded bg-transparent dark:border-gray-600 text-sm text-blue-600"
                    />
                  </td>
                  <td className="p-3">
                    <input 
                      type="date" 
                      value={task.endDate} 
                      onChange={e => updateTask(task.id, { endDate: e.target.value })} 
                      className="w-full p-2 border rounded bg-transparent dark:border-gray-600 text-sm text-blue-600"
                    />
                  </td>
                  <td className="p-3">
                    <input 
                      type="number" 
                      value={task.duration || ''} 
                      onChange={e => updateTask(task.id, { duration: Number(e.target.value) })} 
                      className="w-full p-2 text-center bg-transparent border rounded dark:border-gray-600"
                    />
                  </td>
                  <td className="p-3 text-center">
                    <select 
                      value={task.status} 
                      onChange={e => updateTask(task.id, { status: e.target.value as any })}
                      className={`w-full p-2 rounded text-xs font-bold border-none ${getStatusColor(task.status)} outline-none`}
                    >
                      <option value="not_started">{state.language === 'en' ? 'Not Started' : 'لم تبدأ'}</option>
                      <option value="in_progress">{state.language === 'en' ? 'In Progress' : 'جاري العمل'}</option>
                      <option value="completed">{state.language === 'en' ? 'Completed' : 'مكتملة'}</option>
                    </select>
                  </td>
                  <td className="p-3">
                    <input 
                      type="text" 
                      value={task.notes} 
                      onChange={e => updateTask(task.id, { notes: e.target.value })} 
                      className="w-full p-2 border rounded bg-transparent dark:border-gray-600 text-sm"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-8 text-sm text-gray-500 italic bg-gray-50 dark:bg-gray-800 p-4 rounded-lg print:hidden">
        <p>{state.language === 'en' ? 'Tip: Share this timeline with the client after setting dates — it reduces questions and builds trust.' : 'نصيحة: شارك هذا الجدول مع العميل بعد تحديد التواريخ — ده بيقلل الأسئلة ويبني ثقة.'}</p>
      </div>

    </div>
  );
};
