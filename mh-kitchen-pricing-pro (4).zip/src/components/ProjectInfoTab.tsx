import React from 'react';
import { useAppContext } from '../AppContext';

export const ProjectInfoTab: React.FC = () => {
  const { state, updateProjectInfo, t } = useAppContext();
  const { projectInfo } = state;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    updateProjectInfo({ [e.target.name]: e.target.value });
  };

  const fields = [
    { name: 'customerName', label: 'Customer Name', arLabel: 'اسم العميل', type: 'text' },
    { name: 'projectNumber', label: 'Project Number', arLabel: 'رقم المشروع', type: 'text' },
    { name: 'engineer', label: 'Engineer', arLabel: 'المهندس', type: 'text' },
    { name: 'date', label: 'Date', arLabel: 'التاريخ', type: 'date' },
    { name: 'phone', label: 'Phone', arLabel: 'رقم الهاتف', type: 'tel' },
    { name: 'address', label: 'Address', arLabel: 'العنوان', type: 'text' },
  ];

  return (
    <div className="max-w-3xl animate-in fade-in slide-in-from-bottom-4 duration-500">
      <h2 className="text-2xl font-semibold mb-6 text-gray-900 dark:text-white">
        {t('nav.project_info')}
      </h2>
      
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {fields.map(field => (
            <div key={field.name}>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {state.language === 'en' ? field.label : field.arLabel}
              </label>
              <input
                type={field.type}
                name={field.name}
                value={projectInfo[field.name as keyof typeof projectInfo]}
                onChange={handleChange}
                className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              />
            </div>
          ))}
          
          <div className="col-span-1 md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {state.language === 'en' ? 'Notes' : 'ملاحظات'}
            </label>
            <textarea
              name="notes"
              value={projectInfo.notes}
              onChange={handleChange}
              rows={4}
              className="w-full px-4 py-2 rounded-lg border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
