import React, { useMemo } from 'react';
import { useAppContext } from '../AppContext';
import { calculateTotals } from '../lib/calculations';
import { Ruler, Hammer, Calculator, FileText, Save, FolderOpen, Trash2, ListTodo, Download, TrendingUp, Settings2 } from 'lucide-react';

export const DashboardTab: React.FC = () => {
  const { state, setTab, t, saveProject, savedProjects, loadProject, deleteProject, updateMargins } = useAppContext();
  const totals = useMemo(() => calculateTotals(state), [state]);

  const stats = [
    { 
      labelEn: 'Total Wood Price', labelAr: 'إجمالي الخشب', 
      value: new Intl.NumberFormat(state.language === 'en' ? 'en-SA' : 'ar-SA', { style: 'currency', currency: 'SAR', maximumFractionDigits: 0 }).format(totals.totalWood), 
      icon: Ruler, color: 'text-emerald-500 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-500/10' 
    },
    { 
      labelEn: 'Final Quoted Price', labelAr: 'السعر النهائي المعروض', 
      value: new Intl.NumberFormat(state.language === 'en' ? 'en-SA' : 'ar-SA', { style: 'currency', currency: 'SAR', maximumFractionDigits: 0 }).format(totals.finalPrice), 
      icon: Calculator, color: 'text-indigo-500 dark:text-indigo-400', bg: 'bg-indigo-50 dark:bg-indigo-500/10' 
    },
    { 
      labelEn: 'Net Profit Margin', labelAr: 'نسبة الربح الصافي', 
      value: `${totals.netProfitPercent.toFixed(1)}%`, 
      icon: TrendingUp, color: 'text-amber-500 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-500/10' 
    },
  ];

  return (
    <div className="max-w-6xl animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      
      <div className="flex justify-between items-center mb-8 bg-gradient-to-r from-slate-900 to-slate-800 dark:from-slate-950 dark:to-slate-900 p-8 rounded-2xl shadow-lg border border-slate-700/50 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl -ml-20 -mb-20"></div>
        
        <div className="relative z-10">
          <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">
            {state.language === 'en' ? 'Welcome back' : 'مرحباً بك'}
            {state.projectInfo.engineer ? `, ${state.projectInfo.engineer}` : ''}
          </h2>
          <p className="text-slate-300 font-medium">
            {state.language === 'en' ? 'Here is the current status of your project.' : 'إليك الحالة الحالية لمشروعك.'}
          </p>
        </div>
        <button
          onClick={saveProject}
          className="relative z-10 flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all border border-white/10 shadow-sm backdrop-blur-sm font-medium"
        >
          <Save size={20} />
          {state.language === 'en' ? 'Save Project' : 'حفظ المشروع'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div key={idx} className="bg-white dark:bg-slate-800/80 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-700/60 flex items-center gap-5 transition-transform hover:scale-[1.02] duration-300">
              <div className={`p-4 rounded-xl ${stat.bg}`}>
                <Icon size={26} className={stat.color} />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wider">
                  {state.language === 'en' ? stat.labelEn : stat.labelAr}
                </p>
                <p className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
                  {stat.value}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Cost Estimator */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-800/80 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700/60 overflow-hidden flex flex-col relative">
          <div className="p-6 border-b border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/30">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Settings2 size={20} className="text-indigo-500" />
              {state.language === 'en' ? 'Live Cost Estimator' : 'مقدر التكلفة المباشر'}
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              {state.language === 'en' ? 'Adjust margins & labor quickly' : 'تعديل هوامش الربح والعمالة بسرعة'}
            </p>
          </div>
          <div className="p-6 flex flex-col gap-6 flex-1">
            
            {/* Labor Percentage Slider */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label className="text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Hammer size={16} className="text-slate-400" />
                  {state.language === 'en' ? 'Labor Percentage' : 'نسبة العمالة'}
                </label>
                <span className="text-sm font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-500/10 px-2 py-1 rounded">
                  {state.margins.laborPercent || 0}%
                </span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="50" 
                step="1"
                value={state.margins.laborPercent || 0}
                onChange={e => updateMargins({ laborPercent: Number(e.target.value) })}
                className="w-full accent-blue-500 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer dark:bg-slate-700"
              />
            </div>

            {/* Profit Margin Slider */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  {state.language === 'en' ? 'Target Profit Margin' : 'هامش الربح المستهدف'}
                </label>
                <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-500/10 px-2 py-1 rounded">
                  {state.margins.profitPercent}%
                </span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="100" 
                step="1"
                value={state.margins.profitPercent}
                onChange={e => updateMargins({ profitPercent: Number(e.target.value) })}
                className="w-full accent-indigo-500 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer dark:bg-slate-700"
              />
            </div>

            {/* Contingency Slider */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  {state.language === 'en' ? 'Contingency/Discount Margin' : 'هامش طوارئ / خصومات'}
                </label>
                <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 px-2 py-1 rounded">
                  {state.margins.contingencyPercent}%
                </span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="50" 
                step="1"
                value={state.margins.contingencyPercent}
                onChange={e => updateMargins({ contingencyPercent: Number(e.target.value) })}
                className="w-full accent-emerald-500 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer dark:bg-slate-700"
              />
            </div>

            <div className="pt-4 mt-2 border-t border-slate-100 dark:border-slate-700/60">
              <div className="flex justify-between items-center mb-2">
                <span className="text-slate-500 dark:text-slate-400 text-sm font-medium">
                  {state.language === 'en' ? 'Estimated Quote' : 'العرض التقديري'}
                </span>
                <span className="text-2xl font-black text-slate-900 dark:text-white">
                  {new Intl.NumberFormat(state.language === 'en' ? 'en-SA' : 'ar-SA', { style: 'currency', currency: 'SAR', maximumFractionDigits: 0 }).format(totals.finalPrice)}
                </span>
              </div>
              <p className="text-xs text-slate-400 text-right">
                {state.language === 'en' ? '* Updates instantly' : '* يتم التحديث فورياً'}
              </p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-8">
          {/* Quick Actions */}
          <div className="bg-white dark:bg-slate-800/80 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700/60 overflow-hidden flex flex-col">
            <div className="p-6 border-b border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/30">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <ListTodo size={20} className="text-blue-500" />
                {state.language === 'en' ? 'Quick Actions' : 'إجراءات سريعة'}
              </h3>
            </div>
            <div className="p-6 grid grid-cols-2 gap-4 flex-1">
              <button onClick={() => setTab('project_info')} className="p-4 bg-slate-50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-700/50 rounded-xl hover:border-blue-500 dark:hover:border-blue-500 transition-all text-center flex flex-col items-center justify-center gap-2 group">
                <span className="block font-semibold text-slate-700 dark:text-slate-300 group-hover:text-blue-600 dark:group-hover:text-blue-400">
                  {state.language === 'en' ? 'Edit Info' : 'تعديل البيانات'}
                </span>
              </button>
              <button onClick={() => setTab('pricing')} className="p-4 bg-slate-50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-700/50 rounded-xl hover:border-blue-500 dark:hover:border-blue-500 transition-all text-center flex flex-col items-center justify-center gap-2 group">
                <span className="block font-semibold text-slate-700 dark:text-slate-300 group-hover:text-blue-600 dark:group-hover:text-blue-400">
                  {state.language === 'en' ? 'Kitchen Pricing' : 'تسعير المطبخ'}
                </span>
              </button>
              <button onClick={() => setTab('detailed_costs')} className="p-4 bg-slate-50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-700/50 rounded-xl hover:border-blue-500 dark:hover:border-blue-500 transition-all text-center flex flex-col items-center justify-center gap-2 group">
                <span className="block font-semibold text-slate-700 dark:text-slate-300 group-hover:text-blue-600 dark:group-hover:text-blue-400">
                  {state.language === 'en' ? 'Detailed Costs' : 'تكاليف تفصيلية'}
                </span>
              </button>
              <button onClick={() => setTab('full_cost')} className="p-4 bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-200 dark:border-indigo-800 rounded-xl hover:bg-indigo-600 hover:text-white transition-all text-center shadow-sm flex flex-col items-center justify-center gap-2 group text-indigo-700 dark:text-indigo-400">
                <span className="block font-bold group-hover:text-white">
                  {state.language === 'en' ? 'Full Report' : 'التقرير الشامل'}
                </span>
              </button>
              <button onClick={async () => {
                try {
                  const response = await fetch('/mh_kitchen_pricing_pro.rbz');
                  if (!response.ok) throw new Error('Network response was not ok');
                  const blob = await response.blob();
                  const url = window.URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.style.display = 'none';
                  a.href = url;
                  a.download = 'mh_kitchen_pricing_pro.rbz';
                  document.body.appendChild(a);
                  a.click();
                  window.URL.revokeObjectURL(url);
                  document.body.removeChild(a);
                } catch (error) {
                  console.error('Download failed:', error);
                  alert(state.language === 'en' ? 'Download failed. Please try again.' : 'فشل التحميل. يرجى المحاولة مرة أخرى.');
                }
              }} className="col-span-2 mt-2 p-4 bg-slate-900 dark:bg-slate-950 border border-slate-800 rounded-xl hover:bg-slate-800 transition-all text-center shadow-lg flex flex-col items-center justify-center gap-2 w-full group relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-emerald-600/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <Download size={22} className="text-white relative z-10" />
                <span className="block font-bold text-white relative z-10 tracking-wide">
                  {state.language === 'en' ? 'Download SketchUp Plugin (.rbz)' : 'تحميل إضافة سكيتش أب (.rbz)'}
                </span>
              </button>
            </div>
          </div>

          {/* Saved Projects */}
          <div className="bg-white dark:bg-slate-800/80 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700/60 overflow-hidden flex flex-col">
            <div className="p-6 border-b border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/30">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <FolderOpen size={20} className="text-amber-500" />
                {state.language === 'en' ? 'Saved Projects' : 'المشاريع المحفوظة'}
              </h3>
            </div>
            <div className="p-0 max-h-[400px] overflow-y-auto custom-scrollbar">
              {savedProjects.length === 0 ? (
                <div className="p-10 text-center text-slate-500 dark:text-slate-400 flex flex-col items-center justify-center">
                  <FolderOpen size={40} className="mb-4 text-slate-300 dark:text-slate-600" />
                  <p className="font-medium">{state.language === 'en' ? 'No saved projects yet.' : 'لا توجد مشاريع محفوظة.'}</p>
                </div>
              ) : (
                <ul className="divide-y divide-slate-100 dark:divide-slate-700/60">
                  {savedProjects.map(proj => (
                    <li key={proj.id} className="p-5 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors flex items-center justify-between group">
                      <button 
                        onClick={() => loadProject(proj.id)}
                        className="flex-1 text-left rtl:text-right"
                      >
                        <p className="font-bold text-slate-900 dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                          {proj.state.projectInfo.customerName || (state.language === 'en' ? 'Unnamed Client' : 'عميل بدون اسم')}
                        </p>
                        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                          {new Date(proj.timestamp).toLocaleDateString()}
                        </p>
                      </button>
                      <button 
                        onClick={() => deleteProject(proj.id)}
                        className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-lg transition-all ml-4 rtl:ml-0 rtl:mr-4 opacity-0 group-hover:opacity-100 focus:opacity-100"
                        title={state.language === 'en' ? 'Delete' : 'حذف'}
                      >
                        <Trash2 size={18} />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
        
      </div>

    </div>
  );
};
