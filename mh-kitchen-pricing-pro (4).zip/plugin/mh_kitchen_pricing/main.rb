require 'sketchup.rb'
require 'json'

module MHDesign
  module KitchenPricing

    class SelectionObserver < Sketchup::SelectionObserver
      def initialize(dialog)
        @dialog = dialog
      end
      
      def onSelectionBulkChange(selection)
        send_selection_data(selection)
      end
      
      def onSelectionCleared(selection)
        send_selection_data(selection)
      end
      
      def send_selection_data(selection)
        valid_ents = selection.grep(Sketchup::Group).concat(selection.grep(Sketchup::ComponentInstance))
        if valid_ents.length == 1
          ent = valid_ents.first
          data = MHDesign::KitchenPricing.get_unrotated_dimensions(ent)
          if data
            name = ent.name.empty? ? (ent.is_a?(Sketchup::ComponentInstance) ? ent.definition.name : "Group") : ent.name
            data[:name] = name
            @dialog.execute_script("if(window.skpCallback_onSelectionChange) window.skpCallback_onSelectionChange(#{data.to_json});")
          end
        elsif valid_ents.length > 1
          bb = Geom::BoundingBox.new
          valid_ents.each { |ent| bb.add(ent.bounds) }
          data = {
            width: (bb.width * 2.54).round(2),
            depth: (bb.depth * 2.54).round(2),
            height: (bb.height * 2.54).round(2),
            name: "Multiple Selection (#{valid_ents.length})"
          }
          @dialog.execute_script("if(window.skpCallback_onSelectionChange) window.skpCallback_onSelectionChange(#{data.to_json});")
        else
          @dialog.execute_script("if(window.skpCallback_onSelectionChange) window.skpCallback_onSelectionChange(null);")
        end
      end
    end

    def self.get_unrotated_dimensions(ent)
      return nil unless ent.is_a?(Sketchup::Group) || ent.is_a?(Sketchup::ComponentInstance)
      
      if ent.is_a?(Sketchup::ComponentInstance)
        local_bounds = ent.definition.bounds
      else
        local_bounds = ent.local_bounds
      end
      
      t = ent.transformation
      x_scale = Math.sqrt(t.xaxis.x**2 + t.xaxis.y**2 + t.xaxis.z**2)
      y_scale = Math.sqrt(t.yaxis.x**2 + t.yaxis.y**2 + t.yaxis.z**2)
      z_scale = Math.sqrt(t.zaxis.x**2 + t.zaxis.y**2 + t.zaxis.z**2)
      
      width = local_bounds.width * x_scale * 2.54
      depth = local_bounds.depth * y_scale * 2.54
      height = local_bounds.height * z_scale * 2.54
      
      {
        width: width.round(2),
        depth: depth.round(2),
        height: height.round(2)
      }
    end

    def self.show_dialog
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        return
      end

      @dialog = UI::HtmlDialog.new(
        {
          :dialog_title => "MH Kitchen Pricing Pro",
          :preferences_key => "com.mhdesign.kitchenpricing",
          :scrollable => true,
          :resizable => true,
          :width => 1200,
          :height => 800,
          :left => 100,
          :top => 100,
          :min_width => 800,
          :min_height => 600,
          :max_width => 10000,
          :max_height => 10000,
          :style => UI::HtmlDialog::STYLE_DIALOG
        }
      )
      
      html_path = File.join(__dir__, 'ui', 'index.html')
      @dialog.set_file(html_path)
      
      @observer = SelectionObserver.new(@dialog)
      
      @dialog.set_on_closed do
        Sketchup.active_model.selection.remove_observer(@observer) if @observer
      end

      @dialog.add_action_callback("ready") do |action_context|
        Sketchup.active_model.selection.add_observer(@observer)
        # Send initial selection if any
        @observer.send_selection_data(Sketchup.active_model.selection)
      end

      @dialog.add_action_callback("read_dimensions") do |action_context|
        begin
          model = Sketchup.active_model
          sel = model.selection
          if sel.empty?
            @dialog.execute_script("if(window.skpCallback_onError) window.skpCallback_onError('Please select a component or group in SketchUp to read dimensions.');")
          else
            valid_ents = sel.grep(Sketchup::Group).concat(sel.grep(Sketchup::ComponentInstance))
            if valid_ents.empty?
              @dialog.execute_script("if(window.skpCallback_onError) window.skpCallback_onError('The selected item is not a valid Group or Component.');")
            elsif valid_ents.length == 1
              data = get_unrotated_dimensions(valid_ents.first)
              @dialog.execute_script("if(window.skpCallback_onDimensionsRead) window.skpCallback_onDimensionsRead(#{data.to_json});")
            else
              bb = Geom::BoundingBox.new
              valid_ents.each { |ent| bb.add(ent.bounds) }
              data = {
                width: (bb.width * 2.54).round(2),
                depth: (bb.depth * 2.54).round(2),
                height: (bb.height * 2.54).round(2)
              }
              @dialog.execute_script("if(window.skpCallback_onDimensionsRead) window.skpCallback_onDimensionsRead(#{data.to_json});")
            end
          end
        rescue => e
          @dialog.execute_script("if(window.skpCallback_onError) window.skpCallback_onError(#{e.message.inspect});")
        end
      end

      @dialog.show
    end

    unless file_loaded?(__FILE__)
      menu = UI.menu('Plugins')
      menu.add_item('MH Kitchen Pricing Pro') {
        self.show_dialog
      }
      
      toolbar = UI::Toolbar.new "MH Kitchen Pricing"
      cmd = UI::Command.new("MH Kitchen Pricing") {
        self.show_dialog
      }
      cmd.tooltip = "Open Kitchen Pricing Pro"
      cmd.status_bar_text = "Opening MH Kitchen Pricing Configuration..."
      toolbar = toolbar.add_item cmd
      toolbar.show

      file_loaded(__FILE__)
    end

  end
end
