require 'sketchup.rb'
require 'extensions.rb'

module MHDesign
  module KitchenPricing
    unless file_loaded?(__FILE__)
      ex = SketchupExtension.new('MH Kitchen Pricing Pro', 'mh_kitchen_pricing/main')
      ex.description = 'Professional Kitchen Pricing Configuration Tool.'
      ex.version     = '1.0.0'
      ex.copyright   = '2026 © MH Design'
      ex.creator     = 'MH Design'
      
      Sketchup.register_extension(ex, true)
      file_loaded(__FILE__)
    end
  end
end
