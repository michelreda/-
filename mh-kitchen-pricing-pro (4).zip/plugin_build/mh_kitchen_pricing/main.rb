require 'sketchup.rb'
require 'json'

module MHDesign
  module KitchenPricing

    def self.show_dialog
      @dialog ||= UI::HtmlDialog.new(
        {
          :dialog_title => "MH Kitchen Pricing Pro",
          :preferences_key => "com.mhdesign.kitchenpricing",
          :scrollable => true,
          :resizable => true,
          :width => 1200,
          :height => 800,
          :left => 100,
          :top => 100,
          :min_width => 800,
          :min_height => 600,
          :max_width =>10000,
          :max_height => 10000,
          :style => UI::HtmlDialog::STYLE_DIALOG
        }
      )
      
      html_path = File.join(__dir__, 'ui', 'index.html')
      @dialog.set_file(html_path)
      
      # Register the callback to read dimensions
      @dialog.add_action_callback("read_dimensions") do |action_context|
        begin
          model = Sketchup.active_model
          sel = model.selection
          if sel.empty?
            @dialog.execute_script("if(window.skpCallback_onError) window.skpCallback_onError('Please select a component or group in SketchUp to read dimensions.');")
          else
            valid_ents = sel.grep(Sketchup::Group).concat(sel.grep(Sketchup::ComponentInstance))
            if valid_ents.empty?
              @dialog.execute_script("if(window.skpCallback_onError) window.skpCallback_onError('The selected item is not a valid Group or Component.');")
            else
              bb = Geom::BoundingBox.new
              valid_ents.each { |ent| bb.add(ent.bounds) }
              
              # Convert inches to centimeters (1 inch = 2.54 cm)
              # SketchUp internal units are inches
              data = {
                width: (bb.width * 2.54).round(2),
                depth: (bb.depth * 2.54).round(2),
                height: (bb.height * 2.54).round(2)
              }
              @dialog.execute_script("if(window.skpCallback_onDimensionsRead) window.skpCallback_onDimensionsRead(#{data.to_json});")
            end
          end
        rescue => e
          @dialog.execute_script("if(window.skpCallback_onError) window.skpCallback_onError(#{e.message.inspect});")
        end
      end

      @dialog.show
    end

    unless file_loaded?(__FILE__)
      menu = UI.menu('Plugins')
      menu.add_item('MH Kitchen Pricing Pro') {
        self.show_dialog
      }
      
      toolbar = UI::Toolbar.new "MH Kitchen Pricing"
      cmd = UI::Command.new("MH Kitchen Pricing") {
        self.show_dialog
      }
      cmd.tooltip = "Open Kitchen Pricing Pro"
      cmd.status_bar_text = "Opening MH Kitchen Pricing Configuration..."
      toolbar = toolbar.add_item cmd
      toolbar.show

      file_loaded(__FILE__)
    end

  end
end
